import { useState } from "react";
import Button from "./components/Button";
import Input from "./components/Input";
import Select from "./components/Select";
import StatusBadge, { type Status } from "./components/StatusBadge";

const statuses: Status[] = [
  "Submitted",
  "Reviewing",
  "Rejected",
  "Accepted"
];

export default function App() {
  const [inputValue, setInputValue] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("submitted");

  return (
    <main className="page">
      <header className="page-header">
        <div>
          <h1>Base Components</h1>
          <p className="subtitle">
            Sprint 1 UX component preview simple black and white UI.
          </p>
        </div>
      </header>

      <section className="component-section">
        <h2>Buttons</h2>
        <p className="section-description">
          Primary, secondary and danger button styles.
        </p>
        <div className="component-row">
          <Button>Primary Button</Button>
          <Button variant="secondary">Secondary Button</Button>
        </div>
      </section>

      <section className="component-section">
        <h2>Status Badges</h2>
        <p className="section-description">
          Status styles for applications and candidates.
        </p>
        <div className="component-row badge-row">
          {statuses.map((status) => (
            <StatusBadge key={status} status={status} />
          ))}
        </div>
      </section>

      <section className="component-section">
        <h2>Text Inputs</h2>
        <p className="section-description">
          Standard text input with label and optional error state.
        </p>
        <div className="input-demo">
          <Input
            label="Full Name"
            placeholder="Enter candidate name"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
          />

          <Input
            label="Email Address"
            type="email"
            placeholder="candidate@example.com"
          />

          <Input
            label="Example Error"
            placeholder="Invalid value"
            error="Please enter a valid value."
          />
        </div>
      </section>

      <section className="component-section">
        <h2>Dropdowns</h2>
        <p className="section-description">
          Standard select/dropdown component.
        </p>
        <div className="input-demo">
          <Select
            label="Application Status"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            options={[
              { value: "all", label: "All Statuses" },
              { value: "submitted", label: "Submitted" },
              { value: "reviewing", label: "Reviewing" },
              { value: "accepted", label: "Accepted" },
              { value: "rejected", label: "Rejected" }
            ]}
          />
        </div>
      </section>
    </main>
  );
}