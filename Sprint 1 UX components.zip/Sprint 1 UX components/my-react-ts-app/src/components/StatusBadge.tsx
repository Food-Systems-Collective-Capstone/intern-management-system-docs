export type Status =
  | "Submitted"
  | "Reviewing"
  | "Accepted"
  | "Rejected";

interface StatusBadgeProps {
  status: Status;
}

export default function StatusBadge({ status }: StatusBadgeProps) {
  const className = status.toLowerCase().replace(/\s+/g, "-");

  return (
    <span className={`status-badge status-${className}`}>
      {status}
    </span>
  );
}